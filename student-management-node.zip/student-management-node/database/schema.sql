-- ============================================================
-- Student Management System - MySQL Schema
-- ============================================================
-- Run this file to create the database and table before starting
-- the backend. Example:
--   mysql -u root -p < database/schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;

CREATE TABLE IF NOT EXISTS students (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    roll_number   VARCHAR(30)  UNIQUE NOT NULL,
    department    VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL,
    phone         VARCHAR(10)  NOT NULL
);

-- Optional sample data so the table isn't empty on first run
INSERT INTO students (name, roll_number, department, email, phone) VALUES
('Aarav Mehta', 'CS2023001', 'Computer Science', 'aarav.mehta@example.com', '9876543210'),
('Isha Kapoor', 'EC2023014', 'Electronics',       'isha.kapoor@example.com', '9123456780'),
('Rohan Verma', 'ME2023027', 'Mechanical',        'rohan.verma@example.com', '9988776655');

SELECT * FROM students;
