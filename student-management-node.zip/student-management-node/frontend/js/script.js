// ============================================================
// Student Management System - Frontend Logic
// ============================================================
// IMPORTANT: This file does NOT store student data in the browser.
// Every Create/Read/Update/Delete action goes through fetch() to
// the Express REST API, which reads/writes MySQL. The frontend
// only keeps a temporary in-memory copy of the last server response
// (allStudents) so the table and search box don't need to re-fetch
// on every keystroke.
// ============================================================

// Since the frontend is served BY the same Express server (server.js
// uses express.static), a relative path works whether you open it at
// http://localhost:5000 or any other host/port it's deployed to.
const API_BASE_URL = '/api/students';

// ---- DOM references ----
const studentForm = document.getElementById('studentForm');
const studentIdField = document.getElementById('studentId');
const nameField = document.getElementById('name');
const rollNumberField = document.getElementById('rollNumber');
const departmentField = document.getElementById('department');
const emailField = document.getElementById('email');
const phoneField = document.getElementById('phone');

const formTitle = document.getElementById('formTitle');
const submitBtn = document.getElementById('submitBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');

const studentTableBody = document.getElementById('studentTableBody');
const loadingState = document.getElementById('loadingState');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('searchInput');
const alertBox = document.getElementById('alertBox');

const detailModal = document.getElementById('detailModal');
const detailContent = document.getElementById('detailContent');
const closeModalBtn = document.getElementById('closeModalBtn');

let allStudents = []; // in-memory cache of the last server response, used for instant search filtering
let searchDebounceTimer = null;

// ---- Init ----
document.addEventListener('DOMContentLoaded', () => fetchStudents());
studentForm.addEventListener('submit', handleFormSubmit);
cancelEditBtn.addEventListener('click', resetForm);
searchInput.addEventListener('input', handleSearchInput);
closeModalBtn.addEventListener('click', () => detailModal.classList.add('hidden'));
detailModal.addEventListener('click', (e) => {
  if (e.target === detailModal) detailModal.classList.add('hidden');
});

// ============================================================
// READ - GET /api/students (optionally with ?search=)
// ============================================================
async function fetchStudents(searchTerm = '') {
  showLoading(true);
  try {
    const url = searchTerm
      ? `${API_BASE_URL}?search=${encodeURIComponent(searchTerm)}`
      : API_BASE_URL;

    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to load students');

    allStudents = await res.json();
    renderTable(allStudents);
  } catch (err) {
    showAlert('Could not connect to the server. Is the backend running (npm start)?', 'error');
    renderTable([]);
  } finally {
    showLoading(false);
  }
}

function showLoading(isLoading) {
  loadingState.classList.toggle('hidden', !isLoading);
  if (isLoading) emptyState.classList.add('hidden');
}

function renderTable(students) {
  studentTableBody.innerHTML = '';

  if (students.length === 0) {
    emptyState.classList.remove('hidden');
    return;
  }
  emptyState.classList.add('hidden');

  students.forEach((s) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${s.id}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.rollNumber)}</td>
      <td>${escapeHtml(s.department)}</td>
      <td>${escapeHtml(s.email)}</td>
      <td>${escapeHtml(s.phone)}</td>
      <td class="actions-cell">
        <button class="btn btn-view" onclick="viewStudent(${s.id})">View</button>
        <button class="btn btn-edit" onclick="editStudent(${s.id})">Edit</button>
        <button class="btn btn-delete" onclick="deleteStudent(${s.id})">Delete</button>
      </td>
    `;
    studentTableBody.appendChild(row);
  });
}

// Debounced so we don't fire a network request on every single keystroke
function handleSearchInput() {
  clearTimeout(searchDebounceTimer);
  const term = searchInput.value.trim();
  searchDebounceTimer = setTimeout(() => fetchStudents(term), 250);
}

// ============================================================
// CREATE / UPDATE - shared form submit handler
// ============================================================
async function handleFormSubmit(e) {
  e.preventDefault();
  clearFieldErrors();

  if (!validateForm()) return;

  const studentData = {
    name: nameField.value.trim(),
    rollNumber: rollNumberField.value.trim(),
    department: departmentField.value.trim(),
    email: emailField.value.trim(),
    phone: phoneField.value.trim(),
  };

  const editingId = studentIdField.value;
  submitBtn.disabled = true;

  try {
    let res;
    if (editingId) {
      // UPDATE -> PUT /api/students/:id
      res = await fetch(`${API_BASE_URL}/${editingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentData),
      });
    } else {
      // CREATE -> POST /api/students
      res = await fetch(API_BASE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentData),
      });
    }

    if (!res.ok) {
      await handleApiError(res);
      return;
    }

    showAlert(editingId ? 'Student updated successfully!' : 'Student added successfully!', 'success');
    resetForm();
    fetchStudents(searchInput.value.trim());
  } catch (err) {
    showAlert('Network error: could not reach the server.', 'error');
  } finally {
    submitBtn.disabled = false;
  }
}

// ============================================================
// Client-side validation (mirrors backend rules for instant feedback;
// the backend re-validates everything independently)
// ============================================================
function validateForm() {
  let valid = true;

  if (!nameField.value.trim()) {
    setFieldError('name', 'Name is required');
    valid = false;
  }
  if (!rollNumberField.value.trim()) {
    setFieldError('rollNumber', 'Roll number is required');
    valid = false;
  }
  if (!departmentField.value.trim()) {
    setFieldError('department', 'Department is required');
    valid = false;
  }
  const email = emailField.value.trim();
  if (!email) {
    setFieldError('email', 'Email is required');
    valid = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setFieldError('email', 'Enter a valid email address');
    valid = false;
  }
  const phone = phoneField.value.trim();
  if (!phone) {
    setFieldError('phone', 'Phone number is required');
    valid = false;
  } else if (!/^[0-9]{10}$/.test(phone)) {
    setFieldError('phone', 'Phone number must be exactly 10 digits');
    valid = false;
  }

  return valid;
}

function setFieldError(fieldId, message) {
  document.getElementById(fieldId).classList.add('invalid');
  document.getElementById(fieldId + 'Error').textContent = message;
}

function clearFieldErrors() {
  ['name', 'rollNumber', 'department', 'email', 'phone'].forEach((id) => {
    document.getElementById(id).classList.remove('invalid');
    document.getElementById(id + 'Error').textContent = '';
  });
}

// Reads backend validation / duplicate-roll-number / not-found errors and displays them
async function handleApiError(res) {
  let data;
  try {
    data = await res.json();
  } catch {
    showAlert('An unexpected error occurred (status ' + res.status + ').', 'error');
    return;
  }

  if (res.status === 400 && data.fieldErrors) {
    Object.entries(data.fieldErrors).forEach(([field, msg]) => setFieldError(field, msg));
    showAlert('Please fix the highlighted fields.', 'error');
  } else if (res.status === 409) {
    setFieldError('rollNumber', data.message);
    showAlert(data.message, 'error');
  } else if (res.status === 404) {
    showAlert(data.message, 'error');
  } else {
    showAlert(data.message || 'Something went wrong.', 'error');
  }
}

// ============================================================
// EDIT - populate the form with existing data
// ============================================================
function editStudent(id) {
  const student = allStudents.find((s) => s.id === id);
  if (!student) return;

  studentIdField.value = student.id;
  nameField.value = student.name;
  rollNumberField.value = student.rollNumber;
  departmentField.value = student.department;
  emailField.value = student.email;
  phoneField.value = student.phone;

  formTitle.textContent = 'Edit Student';
  submitBtn.textContent = 'Save Changes';
  cancelEditBtn.classList.remove('hidden');

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
  studentForm.reset();
  studentIdField.value = '';
  formTitle.textContent = 'Add New Student';
  submitBtn.textContent = 'Add Student';
  cancelEditBtn.classList.add('hidden');
  clearFieldErrors();
}

// ============================================================
// VIEW - GET /api/students/:id (fetches fresh data from MySQL)
// ============================================================
async function viewStudent(id) {
  try {
    const res = await fetch(`${API_BASE_URL}/${id}`);
    if (!res.ok) {
      await handleApiError(res);
      return;
    }
    const s = await res.json();
    detailContent.innerHTML = `
      <p><strong>ID:</strong> ${s.id}</p>
      <p><strong>Name:</strong> ${escapeHtml(s.name)}</p>
      <p><strong>Roll Number:</strong> ${escapeHtml(s.rollNumber)}</p>
      <p><strong>Department:</strong> ${escapeHtml(s.department)}</p>
      <p><strong>Email:</strong> ${escapeHtml(s.email)}</p>
      <p><strong>Phone:</strong> ${escapeHtml(s.phone)}</p>
    `;
    detailModal.classList.remove('hidden');
  } catch (err) {
    showAlert('Network error: could not reach the server.', 'error');
  }
}

// ============================================================
// DELETE - confirm, then DELETE /api/students/:id
// ============================================================
async function deleteStudent(id) {
  const student = allStudents.find((s) => s.id === id);
  const label = student ? `${student.name} (${student.rollNumber})` : `#${id}`;

  const confirmed = confirm(`Are you sure you want to delete ${label}? This cannot be undone.`);
  if (!confirmed) return;

  try {
    const res = await fetch(`${API_BASE_URL}/${id}`, { method: 'DELETE' });
    if (!res.ok && res.status !== 204) {
      await handleApiError(res);
      return;
    }
    showAlert('Student deleted successfully.', 'success');
    fetchStudents(searchInput.value.trim());
  } catch (err) {
    showAlert('Network error: could not reach the server.', 'error');
  }
}

// ============================================================
// Helpers
// ============================================================
function showAlert(message, type) {
  alertBox.textContent = message;
  alertBox.className = `alert ${type}`;
  alertBox.classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  setTimeout(() => alertBox.classList.add('hidden'), 4000);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
