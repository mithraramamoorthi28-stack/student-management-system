# Setup Guide & Viva Explanation

## Part 1 — Step-by-Step Setup (for beginners)

### STEP 1 — Install Node.js
Download and install Node.js (LTS version) from https://nodejs.org
Verify it installed correctly:
```bash
node -v
npm -v
```

### STEP 2 — Install MySQL
Download and install MySQL Community Server from https://dev.mysql.com/downloads/
During installation, set a root password and remember it.

### STEP 3 — Create the database
From the project's root folder, run:
```bash
mysql -u root -p < database/schema.sql
```
Enter your MySQL password when prompted. This creates the
`student_management` database and the `students` table, with 3 sample rows.

### STEP 4 — Create the project folders
If you're starting from the provided project, this is already done —
the structure is:
```
student-management-node/
├── frontend/
├── backend/
├── database/
├── .gitignore
└── README.md
```

### STEP 5 — Install npm packages
```bash
cd backend
npm install
```
This installs `express`, `mysql2`, `dotenv`, and `cors` (and `nodemon`
for development).

### STEP 6 — Configure .env
```bash
cp .env.example .env
```
Open `.env` and set your real MySQL username/password:
```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=student_management
PORT=5000
```

### STEP 7 — Start the backend
```bash
npm start
```
You should see:
```
✅ Connected to MySQL database: student_management
 Student Management System backend is running!
 Open in browser: http://localhost:5000
```

### STEP 8 — Open the website
Open your browser and go to:
```
http://localhost:5000
```
The frontend loads and immediately fetches the 3 sample students from MySQL.

### STEP 9 — Test CREATE
Fill in the "Add New Student" form with a new name, roll number,
department, email, and 10-digit phone number, then click **Add Student**.
The new row should appear at the top of the table, and a row should now
exist in MySQL (`SELECT * FROM students;`).

### STEP 10 — Test READ
Refresh the page — the students you added should still be there, proving
they came from MySQL, not from browser memory. Click **View** on any row
to see its full details fetched fresh from the server.

### STEP 11 — Test UPDATE
Click **Edit** on any student, change a field (e.g. department), click
**Save Changes**. The table updates immediately, and the change is
persisted in MySQL.

### STEP 12 — Test DELETE
Click **Delete** on any student, confirm the prompt, and the row
disappears from the table and from MySQL.

---

## Part 2 — Simple Viva Explanation

**Q: What does your project do?**
It's a Student Management System where you can add, view, edit, delete,
and search student records through a web page, and all the data is
permanently stored in a MySQL database.

**Q: What is the architecture?**
Three layers:
1. **Frontend** (HTML/CSS/JS) — the page the user sees and interacts with.
2. **Backend** (Node.js + Express) — a REST API server that receives
   requests from the frontend and decides what to do.
3. **Database** (MySQL) — where the actual student records are stored.

**Q: How does the frontend talk to the backend?**
Using the browser's `fetch()` function to send HTTP requests (GET, POST,
PUT, DELETE) to URLs like `/api/students`. The backend replies with JSON
data, which the JavaScript then uses to update the page.

**Q: How does the backend talk to MySQL?**
Through the `mysql2` npm package. The backend creates a "connection pool"
in `db.js`, and the controller functions run SQL queries like
`SELECT * FROM students` or `INSERT INTO students (...) VALUES (...)`
using that pool. All queries use `?` placeholders instead of directly
inserting user input into the SQL string — this is called a
**parameterized query**, and it prevents SQL injection attacks.

**Q: Walk me through what happens when I click "Add Student".**
1. JavaScript reads the form fields and checks them (validation).
2. It sends a `POST` request to `/api/students` with the data as JSON.
3. Express receives the request and routes it to `createStudent()` in the controller.
4. The controller validates the data again on the server side, and checks
   if the roll number already exists.
5. If everything is valid, it runs an `INSERT` SQL query into MySQL.
6. MySQL saves the new row and returns its generated ID.
7. The backend sends back the created student as JSON with status 201.
8. The frontend receives this, shows a success message, and reloads the table.

**Q: What happens if I try to add a duplicate roll number?**
The backend checks the database for an existing student with that roll
number before inserting. If found, it responds with HTTP status 409
(Conflict) and an error message, which the frontend displays next to the
Roll Number field instead of adding the duplicate.

**Q: Why is the database structured with only one table?**
Because a Student Management System's core concept — a student — doesn't
need to be split across multiple related tables for this scope. Each row
in `students` fully represents one student.

**Q: What would you improve if you had more time?**
Add authentication for staff, pagination for large student lists, and
possibly split students into a separate `departments` table with a
foreign key, to avoid repeating department names as plain text.
