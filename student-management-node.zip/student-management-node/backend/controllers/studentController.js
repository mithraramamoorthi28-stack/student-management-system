// ============================================================
// studentController.js
// ============================================================
// Contains the actual logic for each CRUD operation. Routes call
// these functions; these functions talk to MySQL via db.js.
// All queries use "?" placeholders (parameterized queries) to
// prevent SQL injection - user input is never concatenated
// directly into a SQL string.
// ============================================================

const pool = require('../db');

// ---- Validation helpers ----
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[0-9]{10}$/;

function validateStudent(data) {
  const errors = {};

  if (!data.name || !data.name.trim()) {
    errors.name = 'Name is required';
  }
  if (!data.rollNumber || !data.rollNumber.trim()) {
    errors.rollNumber = 'Roll number is required';
  }
  if (!data.department || !data.department.trim()) {
    errors.department = 'Department is required';
  }
  if (!data.email || !data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!EMAIL_REGEX.test(data.email.trim())) {
    errors.email = 'Enter a valid email address';
  }
  if (!data.phone || !data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!PHONE_REGEX.test(data.phone.trim())) {
    errors.phone = 'Phone number must be exactly 10 digits';
  }

  return errors;
}

// Converts a MySQL row (snake_case) into the camelCase shape the frontend expects
function toClientShape(row) {
  return {
    id: row.id,
    name: row.name,
    rollNumber: row.roll_number,
    department: row.department,
    email: row.email,
    phone: row.phone,
  };
}

// ============================================================
// GET /api/students  - get all students (optionally filtered by ?search=)
// ============================================================
exports.getAllStudents = async (req, res) => {
  try {
    const { search } = req.query;
    let rows;

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      [rows] = await pool.query(
        'SELECT * FROM students WHERE name LIKE ? OR roll_number LIKE ? ORDER BY id DESC',
        [term, term]
      );
    } else {
      [rows] = await pool.query('SELECT * FROM students ORDER BY id DESC');
    }

    res.status(200).json(rows.map(toClientShape));
  } catch (err) {
    console.error('getAllStudents error:', err.message);
    res.status(500).json({ message: 'Failed to fetch students' });
  }
};

// ============================================================
// GET /api/students/:id  - get one student by ID
// ============================================================
exports.getStudentById = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query('SELECT * FROM students WHERE id = ?', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: `Student not found with id: ${id}` });
    }
    res.status(200).json(toClientShape(rows[0]));
  } catch (err) {
    console.error('getStudentById error:', err.message);
    res.status(500).json({ message: 'Failed to fetch student' });
  }
};

// ============================================================
// POST /api/students  - create a new student
// ============================================================
exports.createStudent = async (req, res) => {
  try {
    const { name, rollNumber, department, email, phone } = req.body;
    const fieldErrors = validateStudent({ name, rollNumber, department, email, phone });

    if (Object.keys(fieldErrors).length > 0) {
      return res.status(400).json({ message: 'Validation failed', fieldErrors });
    }

    // Check for duplicate roll number before inserting
    const [existing] = await pool.query('SELECT id FROM students WHERE roll_number = ?', [
      rollNumber.trim(),
    ]);
    if (existing.length > 0) {
      return res.status(409).json({
        message: `A student with roll number '${rollNumber.trim()}' already exists`,
      });
    }

    const [result] = await pool.query(
      'INSERT INTO students (name, roll_number, department, email, phone) VALUES (?, ?, ?, ?, ?)',
      [name.trim(), rollNumber.trim(), department.trim(), email.trim(), phone.trim()]
    );

    const [rows] = await pool.query('SELECT * FROM students WHERE id = ?', [result.insertId]);
    res.status(201).json(toClientShape(rows[0]));
  } catch (err) {
    // Fallback safety net in case the DB UNIQUE constraint catches a race condition
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'A student with this roll number already exists' });
    }
    console.error('createStudent error:', err.message);
    res.status(500).json({ message: 'Failed to create student' });
  }
};

// ============================================================
// PUT /api/students/:id  - update an existing student
// ============================================================
exports.updateStudent = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, rollNumber, department, email, phone } = req.body;
    const fieldErrors = validateStudent({ name, rollNumber, department, email, phone });

    if (Object.keys(fieldErrors).length > 0) {
      return res.status(400).json({ message: 'Validation failed', fieldErrors });
    }

    const [existingStudent] = await pool.query('SELECT * FROM students WHERE id = ?', [id]);
    if (existingStudent.length === 0) {
      return res.status(404).json({ message: `Student not found with id: ${id}` });
    }

    // If the roll number changed, make sure the new one isn't taken by someone else
    if (existingStudent[0].roll_number !== rollNumber.trim()) {
      const [duplicate] = await pool.query(
        'SELECT id FROM students WHERE roll_number = ? AND id != ?',
        [rollNumber.trim(), id]
      );
      if (duplicate.length > 0) {
        return res.status(409).json({
          message: `A student with roll number '${rollNumber.trim()}' already exists`,
        });
      }
    }

    await pool.query(
      'UPDATE students SET name = ?, roll_number = ?, department = ?, email = ?, phone = ? WHERE id = ?',
      [name.trim(), rollNumber.trim(), department.trim(), email.trim(), phone.trim(), id]
    );

    const [rows] = await pool.query('SELECT * FROM students WHERE id = ?', [id]);
    res.status(200).json(toClientShape(rows[0]));
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'A student with this roll number already exists' });
    }
    console.error('updateStudent error:', err.message);
    res.status(500).json({ message: 'Failed to update student' });
  }
};

// ============================================================
// DELETE /api/students/:id  - delete a student
// ============================================================
exports.deleteStudent = async (req, res) => {
  try {
    const { id } = req.params;
    const [existing] = await pool.query('SELECT id FROM students WHERE id = ?', [id]);

    if (existing.length === 0) {
      return res.status(404).json({ message: `Student not found with id: ${id}` });
    }

    await pool.query('DELETE FROM students WHERE id = ?', [id]);
    res.status(204).send();
  } catch (err) {
    console.error('deleteStudent error:', err.message);
    res.status(500).json({ message: 'Failed to delete student' });
  }
};
