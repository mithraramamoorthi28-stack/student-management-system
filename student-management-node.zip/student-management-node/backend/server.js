// ============================================================
// server.js - Express application entry point
// ============================================================
// Starts the HTTP server, wires up the REST API under /api/students,
// and serves the frontend static files so the whole application
// (frontend + backend) can run from a single "npm start" command.
// ============================================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const studentRoutes = require('./routes/studentRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Allow the frontend to call this API even if it's ever opened from a
// different origin/port (e.g. a Live Server extension) instead of being
// served directly by this app.
app.use(cors());

// Parse incoming JSON request bodies (needed for POST/PUT requests)
app.use(express.json());

// Serve the frontend (HTML/CSS/JS) as static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Mount the Student REST API
app.use('/api/students', studentRoutes);

// Fallback: any other route serves the frontend's index.html
// (keeps this a single-server app - one "npm start" runs everything)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Generic error handler (catches anything not handled in the controllers)
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.message);
  res.status(500).json({ message: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log('=================================================');
  console.log(` Student Management System backend is running!`);
  console.log(` Open in browser: http://localhost:${PORT}`);
  console.log(` API base URL:    http://localhost:${PORT}/api/students`);
  console.log('=================================================');
});
