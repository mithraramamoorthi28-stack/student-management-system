// ============================================================
// db.js - MySQL connection pool
// ============================================================
// Uses mysql2/promise so we can use async/await everywhere.
// A "pool" is used instead of a single connection so the server
// can handle multiple requests at the same time efficiently.
// Credentials come from environment variables (.env) - never
// hard-coded - so the password is not committed to GitHub.
// ============================================================

require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'student_management',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Quick check when the server starts, so connection problems are
// reported immediately instead of failing silently on the first request.
pool
  .getConnection()
  .then((connection) => {
    console.log('✅ Connected to MySQL database:', process.env.DB_NAME || 'student_management');
    connection.release();
  })
  .catch((err) => {
    console.error('❌ Could not connect to MySQL:', err.message);
    console.error('   Check your .env file and make sure MySQL is running.');
  });

module.exports = pool;
