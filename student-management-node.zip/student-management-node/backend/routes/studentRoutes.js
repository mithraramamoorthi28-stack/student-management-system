// ============================================================
// studentRoutes.js
// ============================================================
// Defines the URL paths for the Student REST API and connects
// each one to its controller function. Mounted in server.js
// under the "/api/students" prefix.
// ============================================================

const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');

router.get('/', studentController.getAllStudents);       // GET    /api/students
router.get('/:id', studentController.getStudentById);    // GET    /api/students/:id
router.post('/', studentController.createStudent);       // POST   /api/students
router.put('/:id', studentController.updateStudent);      // PUT    /api/students/:id
router.delete('/:id', studentController.deleteStudent);   // DELETE /api/students/:id

module.exports = router;
